#ifndef ASMPARSER_H
#define ASMPARSER_H
#include "ParseResult.h"
#include <stdbool.h>

#define NUM_REGISTERS 32
#define NUM_INSTRUCTIONS 24

typedef struct _MIPSInstruction {
   char* mnemonic;
   char* opcode;
   char* funct;
} MIPSInstruction;


/**  Breaks up given MIPS32 assembly instruction and creates a proper 
 *   ParseResult object storing information about that instruction.
 * 
 *   Pre:  pASM points to an array holding the bits (as chars) of a
 *         syntactically valid assembly instruction, whose mnemonic is
 *         one of the following:
 *             add  addi  and  andi  lui  lw  or  ori  sub
 * 
 *   Returns:
 *         A pointer to a proper ParseResult object whose fields have been
 *         correctly initialized to correspond to the target of pASM.
 */
ParseResult* parseASM(const char* const pASM);

bool isInstruction(char* s);



#endif
